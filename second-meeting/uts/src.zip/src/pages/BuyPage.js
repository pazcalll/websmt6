import {React, useState, Component} from "react";

const BuyPage = (props) => {
    return(
        <div>
            
        </div>
    )
}